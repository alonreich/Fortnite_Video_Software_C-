// [SPEC CONTRACT] STRICT GOVERNANCE:
// Forbidden to modify without reading: docs/05_SYSTEM_LIFECYCLE_STORAGE.md
// Invariants, constants, and threading models must match spec bit-for-bit.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using FortniteVideoSoftware.Core.Infrastructure;

namespace FortniteVideoSoftware.App;

/// <summary>
/// On startup, sweeps the Windows Application event log for THIS app's crash / hang
/// entries (Application Error, .NET Runtime, Application Hang, Windows Error Reporting)
/// that occurred since the last sweep and folds them into RuntimeLog — so native crashes
/// that only Windows Error Reporting saw (the ones you'd otherwise dig out of Event Viewer
/// by hand) end up in the same .log file as everything else.
///
/// NativeAOT-safe: shells out to the built-in <c>wevtutil.exe</c> instead of the
/// reflection-heavy <c>System.Diagnostics.EventLog</c> managed API. Reading the Application
/// log does not require elevation.
/// </summary>
internal static class CrashLogDigest
{
    /// <summary>Fire-and-forget: runs off the UI/startup thread so it never delays launch.</summary>
    public static Task RunAsync() => Task.Run(Run);

    private static async Task Run()
    {
        try
        {
            string markerPath = RuntimeLog.LogPath + ".crashdigest";
            DateTime sinceUtc = ReadMarker(markerPath);
            DateTime sweepStartedUtc = DateTime.UtcNow;

            string exe = Path.GetFileName(Environment.ProcessPath ?? "FortniteVideoSoftware.App.exe");
            string sinceIso = sinceUtc.ToString("yyyy-MM-ddTHH:mm:ss.fffZ", CultureInfo.InvariantCulture);

            string query =
                "*[System[(Provider[@Name='Application Error'] or Provider[@Name='.NET Runtime'] " +
                "or Provider[@Name='Application Hang'] or Provider[@Name='Windows Error Reporting']) " +
                $"and TimeCreated[@SystemTime>='{sinceIso}']]]";

            var psi = new ProcessStartInfo
            {
                FileName = "wevtutil.exe",
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true,
                StandardOutputEncoding = Encoding.UTF8,
            };
            psi.ArgumentList.Add("qe");
            psi.ArgumentList.Add("Application");
            psi.ArgumentList.Add("/q:" + query);
            psi.ArgumentList.Add("/f:text");
            psi.ArgumentList.Add("/rd:true");
            psi.ArgumentList.Add("/c:100");

            using var proc = Process.Start(psi);
            if (proc == null) return;

            var readOutput = proc.StandardOutput.ReadToEndAsync();
            var readError = proc.StandardError.ReadToEndAsync();

            using var cts = new System.Threading.CancellationTokenSource(15000);
            try
            {
                await proc.WaitForExitAsync(cts.Token).ConfigureAwait(false);
            }
            catch (OperationCanceledException)
            {
                // wevtutil is NOT an interactive stdin tool, so the cooperative 'q' quit
                // command is skipped: escalate straight to the bounded hard stop
                // (Kill(entireProcessTree) → 2000 ms exit confirmation). Never throws.
                await GracefulProcessTerminator.TerminateAsync(
                    proc, "EVENTLOG DIGEST", attemptQuitCommand: false).ConfigureAwait(false);
            }

            string output = await readOutput.ConfigureAwait(false);
            _ = await readError.ConfigureAwait(false);

            int ingested = 0;
            if (!string.IsNullOrWhiteSpace(output))
            {
                foreach (string block in SplitEvents(output))
                {
                    if (block.IndexOf("FortniteVideoSoftware", StringComparison.OrdinalIgnoreCase) < 0
                        && block.IndexOf(exe, StringComparison.OrdinalIgnoreCase) < 0
                        && block.IndexOf("ffmpeg.exe", StringComparison.OrdinalIgnoreCase) < 0
                        && block.IndexOf("ffprobe.exe", StringComparison.OrdinalIgnoreCase) < 0)
                        continue;

                    RuntimeLog.Fail("EVENTLOG CRASH", Condense(block));
                    ingested++;
                }
            }

            if (ingested > 0)
                RuntimeLog.Info("EVENTLOG DIGEST",
                    $"Folded {ingested} crash/error event(s) from Windows Event Viewer (since {sinceIso}) into this log.");

            WriteMarker(markerPath, sweepStartedUtc);
        }
        catch (Exception ex)
        {
            RuntimeLog.Fail("EVENTLOG DIGEST", $"Crash log digest failed completely: {ex.Message}");
        }
    }

    private static IEnumerable<string> SplitEvents(string text)
    {
        var sb = new StringBuilder();
        foreach (string line in text.Split('\n'))
        {
            if (line.StartsWith("Event[", StringComparison.Ordinal) && sb.Length > 0)
            {
                yield return sb.ToString();
                sb.Clear();
            }
            sb.Append(line).Append('\n');
        }
        if (sb.Length > 0) yield return sb.ToString();
    }

    /// <summary>Collapse a wevtutil text block into one readable line, dropping boilerplate.</summary>
    private static string Condense(string block)
    {
        var keep = new List<string>();
        foreach (string raw in block.Split('\n'))
        {
            string line = raw.Trim();
            if (line.Length == 0) continue;
            if (line.StartsWith("Event[", StringComparison.Ordinal)) continue;
            if (StartsWithAny(line, "Log Name:", "Level:", "Opcode:", "Task:", "Keyword:",
                    "User:", "User Name:", "Computer:", "Record Id:", "Correlation:", "Execution:")) continue;
            if (line.Equals("Description:", StringComparison.OrdinalIgnoreCase)) continue;
            keep.Add(line);
        }

        string joined = string.Join(" | ", keep);
        const int cap = 1200;
        if (joined.Length > cap) joined = joined.Substring(0, cap) + " …(truncated)";
        return joined;
    }

    private static bool StartsWithAny(string line, params string[] prefixes)
    {
        foreach (string p in prefixes)
            if (line.StartsWith(p, StringComparison.OrdinalIgnoreCase)) return true;
        return false;
    }

    private static DateTime ReadMarker(string path)
    {
        try
        {
            using var mutex = new System.Threading.Mutex(false, "Global\\FortniteVideoSoftwareCrashDigestMutex");
            bool acquired = false;
            try
            {
                try { acquired = mutex.WaitOne(2000); } catch (System.Threading.AbandonedMutexException) { acquired = true; }
                if (File.Exists(path))
                {
                    using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                    using var sr = new StreamReader(fs, Encoding.UTF8);
                    string s = sr.ReadToEnd().Trim();
                    if (DateTime.TryParse(s, CultureInfo.InvariantCulture,
                            DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal, out DateTime dt))
                        return dt.ToUniversalTime();
                }
            }
            finally { if (acquired) mutex.ReleaseMutex(); }
        }
        catch (Exception ex) 
        { 
            RuntimeLog.Info("EVENTLOG DIGEST", $"ReadMarker failed, falling back to 3 days ago: {ex.Message}"); 
        }
        return DateTime.UtcNow.AddDays(-3);
    }

    private static void WriteMarker(string path, DateTime utc)
    {
        try
        {
            using var mutex = new System.Threading.Mutex(false, "Global\\FortniteVideoSoftwareCrashDigestMutex");
            bool acquired = false;
            try
            {
                try { acquired = mutex.WaitOne(2000); } catch (System.Threading.AbandonedMutexException) { acquired = true; }
                using var fs = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.ReadWrite);
                using var sw = new StreamWriter(fs, new UTF8Encoding(false));
                sw.Write(utc.ToString("yyyy-MM-ddTHH:mm:ss.fffZ", CultureInfo.InvariantCulture));
                sw.Flush();
            }
            finally { if (acquired) mutex.ReleaseMutex(); }
        }
        catch (Exception ex) 
        { 
            RuntimeLog.Info("EVENTLOG DIGEST", $"WriteMarker failed: {ex.Message}"); 
        }
    }
}
